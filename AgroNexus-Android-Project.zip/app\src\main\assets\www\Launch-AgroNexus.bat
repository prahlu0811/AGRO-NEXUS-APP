@echo off
title AgroNexus — Crop Health & Farm Assistant
echo ========================================================
echo        Starting AgroNexus Kisan Smart App...
echo ========================================================
echo.

set "TARGET_URL=file:///%~dp0index.html"
set "TARGET_URL=%TARGET_URL:\=/%"

:: Try opening in standalone app mode (Edge or Chrome) for a native app feel
where msedge >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo Launching in App Window (Microsoft Edge)...
    start "" msedge --app="%TARGET_URL%"
    goto done
)

where chrome >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo Launching in App Window (Google Chrome)...
    start "" chrome --app="%TARGET_URL%"
    goto done
)

:: Fallback to default browser
echo Opening in default browser...
start "" "%~dp0index.html"

:done
echo AgroNexus is running!
exit /b 0
