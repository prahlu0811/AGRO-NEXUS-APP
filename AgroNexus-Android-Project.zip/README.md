# AgroNexus — Android APK Project

This is the complete Android Native App project for **AgroNexus**. The web application is bundled inside the APK assets (`app/src/main/assets/www`), meaning it runs **100% offline without needing internet**.

---

## 📲 3 Ways to Get Your APK

### Method 1: Instant Install via Android Chrome (WebAPK)
You don't even need Android Studio to get the app on your phone right now:
1. Open Chrome on your Android phone.
2. Visit your running AgroNexus app (or host the `AgroNexus-App` folder on Netlify/Vercel for free).
3. Tap the **"Install"** button in the top header (or tap the 3 dots menu in Chrome `⋮` -> **"Install App"**).
4. Android's official WebAPK engine automatically mints and installs a native APK on your home screen and app drawer with camera and offline access!

---

### Method 2: Build APK via Android Studio (Local)
1. Open **Android Studio**.
2. Click **Open** and select this directory: `c:\Users\prahl\Downloads\AgroNexus-Android`
3. Wait for Gradle sync to complete.
4. In the top menu, click **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
5. Once compiled, click **"locate"** in the notification to get your `app-debug.apk`. Transfer this file to your phone and install!

---

### Method 3: Cloud 1-Click Build via GitHub Actions
We have pre-configured a GitHub Actions workflow in `.github/workflows/build-apk.yml`:
1. Push this `AgroNexus-Android` directory to your GitHub account.
2. Go to the **Actions** tab on your GitHub repository.
3. Select **"Build Android APK"** and click **Run workflow**.
4. Once completed (approx. 2 minutes), download the generated **`AgroNexus-Debug-APK`** artifact directly to your phone.

---

## 🛠️ Project Configuration

- **Package ID:** `com.agronexus.app`
- **Permissions:** Camera (`android.permission.CAMERA`), Audio Recording (`android.permission.RECORD_AUDIO`), Storage/Media.
- **Hardware Acceleration:** Enabled for smooth camera scanning and transitions.
- **Offline Bundle:** Internal assets located at `app/src/main/assets/www`.
